import React from 'react';
import { BarChart3, Calculator as CalculatorIcon, DollarSign, TrendingUp } from 'lucide-react';
import Calculator from './Calculator';
import CalculationHistory from './CalculationHistory';
import { useCalculations } from '../hooks/useCalculations';
import { formatCurrency } from '../utils/calculations';

interface DashboardProps {
  userId: string;
}

const Dashboard: React.FC<DashboardProps> = ({ userId }) => {
  const { calculations, addCalculation, clearHistory } = useCalculations(userId);

  const stats = {
    totalCalculations: calculations.length,
    totalInvestment: calculations.reduce((sum, calc) => sum + calc.initialAmount, 0),
    totalInterest: calculations.reduce((sum, calc) => sum + calc.totalInterest, 0),
    averageReturn: calculations.length > 0 
      ? calculations.reduce((sum, calc) => sum + calc.interestRate, 0) / calculations.length 
      : 0,
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Financial Dashboard</h1>
        <p className="text-gray-600 mt-2">Track your investments and calculate returns</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Calculations</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalCalculations}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <CalculatorIcon className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Investment</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.totalInvestment)}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Interest</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(stats.totalInterest)}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average Return</p>
              <p className="text-2xl font-bold text-gray-900">{stats.averageReturn.toFixed(2)}%</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <BarChart3 className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Calculator and History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <Calculator onCalculate={addCalculation} />
        </div>
        <div>
          <CalculationHistory calculations={calculations} onClearHistory={clearHistory} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;