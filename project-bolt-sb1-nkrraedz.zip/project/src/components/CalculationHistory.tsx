import React from 'react';
import { History, Trash2, Calendar, DollarSign, TrendingUp, Clock } from 'lucide-react';
import { Calculation } from '../types';
import { formatCurrency } from '../utils/calculations';

interface CalculationHistoryProps {
  calculations: Calculation[];
  onClearHistory: () => void;
}

const CalculationHistory: React.FC<CalculationHistoryProps> = ({ calculations, onClearHistory }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDuration = (months: number, days: number) => {
    const totalDays = (months * 30) + days;
    if (months && days) {
      return `${totalDays} days (${months}m + ${days}d)`;
    } else if (months) {
      return `${totalDays} days (${months} months)`;
    } else {
      return `${days} days`;
    }
  };

  if (calculations.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-green-100 p-2 rounded-lg">
            <History className="h-6 w-6 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Calculation History</h2>
        </div>
        <div className="text-center py-8">
          <History className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2 text-gray-500">No calculations yet. Start calculating to see your history!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-green-100 p-2 rounded-lg">
            <History className="h-6 w-6 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Calculation History</h2>
        </div>
        <button
          onClick={onClearHistory}
          className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
        >
          <Trash2 size={16} />
          <span>Clear History</span>
        </button>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {calculations.map((calculation) => (
          <div key={calculation.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-blue-600" />
                <span className="font-medium text-gray-900 capitalize">
                  {calculation.interestType} Interest
                </span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Calendar className="h-4 w-4" />
                <span>{formatDate(calculation.createdAt)}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Initial Amount</p>
                <p className="font-semibold text-gray-900">{formatCurrency(calculation.initialAmount)}</p>
              </div>
              <div>
                <p className="text-gray-600">Duration</p>
                <div className="flex items-center space-x-1">
                  <Clock className="h-3 w-3 text-gray-400" />
                  <p className="font-semibold text-gray-900">
                    {formatDuration(calculation.months, calculation.days)}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-gray-600">Interest Rate</p>
                <p className="font-semibold text-gray-900">{calculation.interestRate}%</p>
              </div>
              <div>
                <p className="text-gray-600">Final Amount</p>
                <p className="font-semibold text-green-600">{formatCurrency(calculation.finalAmount)}</p>
              </div>
            </div>
            
            <div className="mt-3 pt-3 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Interest Earned:</span>
                <span className="font-semibold text-green-600">{formatCurrency(calculation.totalInterest)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalculationHistory;