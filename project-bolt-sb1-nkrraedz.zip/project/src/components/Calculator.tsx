import React, { useState, useEffect } from 'react';
import { Calculator as CalculatorIcon, DollarSign, Calendar, Percent, TrendingUp, Clock } from 'lucide-react';
import { calculateSimpleInterest, calculateCompoundInterest, formatCurrency } from '../utils/calculations';

interface CalculatorProps {
  onCalculate: (calculation: {
    initialAmount: number;
    months: number;
    days: number;
    interestRate: number;
    interestType: 'simple' | 'compound';
    finalAmount: number;
    totalInterest: number;
  }) => void;
}

const Calculator: React.FC<CalculatorProps> = ({ onCalculate }) => {
  const [formData, setFormData] = useState({
    initialAmount: '',
    months: '',
    days: '',
    interestRate: '',
    interestType: 'compound' as 'simple' | 'compound',
  });
  const [result, setResult] = useState<{ finalAmount: number; totalInterest: number } | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.initialAmount) {
      newErrors.initialAmount = 'Initial amount is required';
    } else if (parseFloat(formData.initialAmount) <= 0) {
      newErrors.initialAmount = 'Initial amount must be greater than 0';
    }

    if (!formData.months && !formData.days) {
      newErrors.duration = 'Please specify either months or days';
    }

    if (formData.months && parseInt(formData.months) <= 0) {
      newErrors.months = 'Number of months must be greater than 0';
    }

    if (formData.days && parseInt(formData.days) <= 0) {
      newErrors.days = 'Number of days must be greater than 0';
    }

    if (!formData.interestRate) {
      newErrors.interestRate = 'Interest rate is required';
    } else if (parseFloat(formData.interestRate) < 0) {
      newErrors.interestRate = 'Interest rate cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateTimeInYears = () => {
    let timeInYears = 0;
    
    if (formData.months) {
      timeInYears += parseInt(formData.months) / 12;
    }
    
    if (formData.days) {
      timeInYears += parseInt(formData.days) / 365;
    }
    
    return timeInYears;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const principal = parseFloat(formData.initialAmount);
      const months = parseInt(formData.months) || 0;
      const days = parseInt(formData.days) || 0;
      const rate = parseFloat(formData.interestRate);
      const timeInYears = calculateTimeInYears();

      const calculation = formData.interestType === 'simple'
        ? calculateSimpleInterest(principal, rate, timeInYears)
        : calculateCompoundInterest(principal, rate, timeInYears);

      setResult(calculation);
      onCalculate({
        initialAmount: principal,
        months,
        days,
        interestRate: rate,
        interestType: formData.interestType,
        finalAmount: calculation.finalAmount,
        totalInterest: calculation.totalInterest,
      });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name] || errors.duration) {
      setErrors(prev => ({ ...prev, [name]: '', duration: '' }));
    }
  };

  // Real-time calculation
  useEffect(() => {
    if (formData.initialAmount && (formData.months || formData.days) && formData.interestRate) {
      const principal = parseFloat(formData.initialAmount);
      const rate = parseFloat(formData.interestRate);
      
      if (principal > 0 && rate >= 0) {
        const timeInYears = calculateTimeInYears();
        if (timeInYears > 0) {
          const calculation = formData.interestType === 'simple'
            ? calculateSimpleInterest(principal, rate, timeInYears)
            : calculateCompoundInterest(principal, rate, timeInYears);
          
          setResult(calculation);
        }
      }
    }
  }, [formData]);

  const getTotalDuration = () => {
    const months = parseInt(formData.months) || 0;
    const days = parseInt(formData.days) || 0;
    const totalDays = (months * 30) + days;
    return totalDays;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="bg-blue-100 p-2 rounded-lg">
          <CalculatorIcon className="h-6 w-6 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900">Interest Calculator</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="initialAmount" className="block text-sm font-medium text-gray-700 mb-2">
              Initial Amount
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                id="initialAmount"
                name="initialAmount"
                type="number"
                step="0.01"
                value={formData.initialAmount}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter initial amount"
              />
            </div>
            {errors.initialAmount && <p className="mt-1 text-sm text-red-600">{errors.initialAmount}</p>}
          </div>

          <div>
            <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700 mb-2">
              Interest Rate (%)
            </label>
            <div className="relative">
              <Percent className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                id="interestRate"
                name="interestRate"
                type="number"
                step="0.01"
                value={formData.interestRate}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter interest rate"
              />
            </div>
            {errors.interestRate && <p className="mt-1 text-sm text-red-600">{errors.interestRate}</p>}
          </div>

          <div>
            <label htmlFor="months" className="block text-sm font-medium text-gray-700 mb-2">
              Number of Months
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                id="months"
                name="months"
                type="number"
                value={formData.months}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter number of months"
              />
            </div>
            {errors.months && <p className="mt-1 text-sm text-red-600">{errors.months}</p>}
          </div>

          <div>
            <label htmlFor="days" className="block text-sm font-medium text-gray-700 mb-2">
              Number of Days
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                id="days"
                name="days"
                type="number"
                value={formData.days}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter number of days"
              />
            </div>
            {errors.days && <p className="mt-1 text-sm text-red-600">{errors.days}</p>}
          </div>

          <div className="md:col-span-2">
            <label htmlFor="interestType" className="block text-sm font-medium text-gray-700 mb-2">
              Interest Type
            </label>
            <div className="relative">
              <TrendingUp className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <select
                id="interestType"
                name="interestType"
                value={formData.interestType}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                <option value="compound">Compound Interest</option>
                <option value="simple">Simple Interest</option>
              </select>
            </div>
          </div>
        </div>

        {errors.duration && <p className="text-sm text-red-600">{errors.duration}</p>}

        {(formData.months || formData.days) && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-700">
              <strong>Total Duration:</strong> {getTotalDuration()} days
              {formData.months && formData.days && (
                <span> ({formData.months} months + {formData.days} days)</span>
              )}
            </p>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white py-3 px-6 rounded-lg hover:from-blue-700 hover:to-green-700 transition-all duration-200 font-medium"
        >
          Calculate Interest
        </button>
      </form>

      {result && (
        <div className="mt-6 p-6 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-blue-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Calculation Result</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-sm text-gray-600">Initial Amount</p>
              <p className="text-xl font-bold text-blue-600">
                {formatCurrency(parseFloat(formData.initialAmount))}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">Interest Earned</p>
              <p className="text-xl font-bold text-green-600">
                {formatCurrency(result.totalInterest)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">Final Amount</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(result.finalAmount)}
              </p>
            </div>
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-600">
              Duration: {getTotalDuration()} days
              {formData.months && formData.days && (
                <span> ({formData.months} months + {formData.days} days)</span>
              )}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calculator;