import React, { useState } from 'react';
import { useAuth } from './hooks/useAuth';
import Header from './components/Header';
import AuthForm from './components/AuthForm';
import Dashboard from './components/Dashboard';

function App() {
  const { user, isAuthenticated, signIn, signUp, signOut } = useAuth();
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [authError, setAuthError] = useState<string>('');

  const handleAuthSubmit = (data: { email: string; password: string; name?: string }) => {
    setAuthError('');
    
    if (authMode === 'signin') {
      const success = signIn(data.email, data.password);
      if (!success) {
        setAuthError('Invalid email or password');
      }
    } else {
      const success = signUp(data.email, data.password, data.name || '');
      if (!success) {
        setAuthError('User with this email already exists');
      }
    }
  };

  const handleToggleMode = () => {
    setAuthMode(authMode === 'signin' ? 'signup' : 'signin');
    setAuthError('');
  };

  const handleSignOut = () => {
    signOut();
    setAuthMode('signin');
    setAuthError('');
  };

  if (!isAuthenticated) {
    return (
      <AuthForm
        mode={authMode}
        onSubmit={handleAuthSubmit}
        onToggleMode={handleToggleMode}
        error={authError}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} onSignOut={handleSignOut} />
      <main>
        <Dashboard userId={user?.id || ''} />
      </main>
    </div>
  );
}

export default App;