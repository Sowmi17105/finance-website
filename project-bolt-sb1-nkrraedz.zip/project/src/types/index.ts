export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface Calculation {
  id: string;
  userId: string;
  initialAmount: number;
  months: number;
  days: number;
  interestRate: number;
  interestType: 'simple' | 'compound';
  finalAmount: number;
  totalInterest: number;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}