export const calculateSimpleInterest = (
  principal: number,
  rate: number,
  time: number
): { finalAmount: number; totalInterest: number } => {
  const totalInterest = (principal * rate * time) / 100;
  const finalAmount = principal + totalInterest;
  
  return {
    finalAmount: Math.round(finalAmount * 100) / 100,
    totalInterest: Math.round(totalInterest * 100) / 100,
  };
};

export const calculateCompoundInterest = (
  principal: number,
  rate: number,
  time: number,
  compoundingFrequency: number = 12
): { finalAmount: number; totalInterest: number } => {
  const finalAmount = principal * Math.pow(1 + rate / (100 * compoundingFrequency), compoundingFrequency * time);
  const totalInterest = finalAmount - principal;
  
  return {
    finalAmount: Math.round(finalAmount * 100) / 100,
    totalInterest: Math.round(totalInterest * 100) / 100,
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(amount);
};