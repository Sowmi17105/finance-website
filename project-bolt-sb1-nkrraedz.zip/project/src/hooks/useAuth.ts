import { useState, useEffect } from 'react';
import { User, AuthState } from '../types';

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
  });

  useEffect(() => {
    const storedUser = localStorage.getItem('financeUser');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      setAuthState({
        user,
        isAuthenticated: true,
      });
    }
  }, []);

  const signUp = (email: string, password: string, name: string): boolean => {
    const users = JSON.parse(localStorage.getItem('financeUsers') || '[]');
    
    // Check if user already exists
    if (users.find((user: User) => user.email === email)) {
      return false;
    }

    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    localStorage.setItem('financeUsers', JSON.stringify(users));
    localStorage.setItem('financeUser', JSON.stringify(newUser));
    localStorage.setItem(`userPassword_${newUser.id}`, password);
    
    setAuthState({
      user: newUser,
      isAuthenticated: true,
    });
    
    return true;
  };

  const signIn = (email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem('financeUsers') || '[]');
    const user = users.find((user: User) => user.email === email);
    
    if (!user) {
      return false;
    }

    const storedPassword = localStorage.getItem(`userPassword_${user.id}`);
    if (storedPassword !== password) {
      return false;
    }

    localStorage.setItem('financeUser', JSON.stringify(user));
    setAuthState({
      user,
      isAuthenticated: true,
    });
    
    return true;
  };

  const signOut = () => {
    localStorage.removeItem('financeUser');
    setAuthState({
      user: null,
      isAuthenticated: false,
    });
  };

  return {
    ...authState,
    signUp,
    signIn,
    signOut,
  };
};