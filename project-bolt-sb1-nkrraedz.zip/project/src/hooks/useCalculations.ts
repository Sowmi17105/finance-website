import { useState, useEffect } from 'react';
import { Calculation } from '../types';

export const useCalculations = (userId: string | null) => {
  const [calculations, setCalculations] = useState<Calculation[]>([]);

  useEffect(() => {
    if (userId) {
      const storedCalculations = localStorage.getItem(`calculations_${userId}`);
      if (storedCalculations) {
        setCalculations(JSON.parse(storedCalculations));
      }
    }
  }, [userId]);

  const addCalculation = (calculation: Omit<Calculation, 'id' | 'userId' | 'createdAt'>) => {
    if (!userId) return;

    const newCalculation: Calculation = {
      ...calculation,
      id: Date.now().toString(),
      userId,
      createdAt: new Date().toISOString(),
    };

    const updatedCalculations = [newCalculation, ...calculations];
    setCalculations(updatedCalculations);
    localStorage.setItem(`calculations_${userId}`, JSON.stringify(updatedCalculations));
  };

  const clearHistory = () => {
    if (!userId) return;
    
    setCalculations([]);
    localStorage.removeItem(`calculations_${userId}`);
  };

  return {
    calculations,
    addCalculation,
    clearHistory,
  };
};